"""Server-side SVG charts.

Hand-rolled on purpose: the platform already renders the interaction map as SVG,
and generating the charts the same way keeps the export dependency-free (no
matplotlib in a deployed folder) and makes the output testable as text.
"""
from __future__ import annotations

import math
from xml.sax.saxutils import escape

POSITIVE = "#0f766e"
NEGATIVE = "#94a3b8"
AXIS = "#cbd5e1"
INK = "#1f2937"
MUTED = "#64748b"


def _scale(value: float, low: float, high: float) -> float:
    span = (high - low) or 1.0
    return (value - low) / span


def bar_chart(labels: list[str], values: list[float], title: str,
              subtitle: str = "", width: int = 840, height: int = 400,
              value_format: str = "{:.2f}") -> str:
    """Vertical bar chart with a zero baseline and signed colours."""
    if not labels or len(labels) != len(values):
        raise ValueError("labels and values must be non-empty and the same length")

    left, right, top, bottom = 74, 26, 54, 104
    plot_w = width - left - right
    plot_h = height - top - bottom
    low = min(0.0, min(values))
    high = max(0.0, max(values))
    if high == low:
        high = low + 1.0
    pad = (high - low) * 0.12
    high += pad
    if low < 0:
        low -= pad

    def y_of(value: float) -> float:
        return top + plot_h * (1 - _scale(value, low, high))

    zero_y = y_of(0.0)
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}" font-family="Helvetica, Arial, sans-serif">',
        f'<rect width="{width}" height="{height}" fill="#ffffff"/>',
        f'<text x="{left}" y="26" font-size="15" font-weight="600" fill="{INK}">'
        f'{escape(title)}</text>',
    ]
    if subtitle:
        parts.append(f'<text x="{left}" y="43" font-size="11" fill="{MUTED}">'
                     f'{escape(subtitle)}</text>')

    # y axis and ticks
    ticks = 4
    for index in range(ticks + 1):
        value = low + (high - low) * index / ticks
        y = y_of(value)
        parts.append(f'<line x1="{left}" y1="{y:.1f}" x2="{width - right}" '
                     f'y2="{y:.1f}" stroke="{AXIS}" stroke-width="0.8" '
                     f'stroke-dasharray="3 4"/>')
        parts.append(f'<text x="{left - 8}" y="{y + 4:.1f}" font-size="10" '
                     f'text-anchor="end" fill="{MUTED}">{value:.2f}</text>')
    parts.append(f'<line x1="{left}" y1="{zero_y:.1f}" x2="{width - right}" '
                 f'y2="{zero_y:.1f}" stroke="#94a3b8" stroke-width="1.2"/>')

    slot = plot_w / len(labels)
    bar_w = max(6.0, slot * 0.58)
    for index, (label, value) in enumerate(zip(labels, values)):
        cx = left + slot * (index + 0.5)
        y = y_of(value)
        top_y = min(y, zero_y)
        height_px = abs(zero_y - y)
        colour = POSITIVE if value >= 0 else NEGATIVE
        parts.append(f'<rect x="{cx - bar_w / 2:.1f}" y="{top_y:.1f}" '
                     f'width="{bar_w:.1f}" height="{height_px:.1f}" fill="{colour}" '
                     f'fill-opacity="0.9" rx="2"/>')
        text_y = top_y - 6 if value >= 0 else top_y + height_px + 13
        parts.append(f'<text x="{cx:.1f}" y="{text_y:.1f}" font-size="9.5" '
                     f'text-anchor="middle" fill="{MUTED}">'
                     f'{escape(value_format.format(value))}</text>')
        parts.append(f'<text transform="translate({cx:.1f},{height - bottom + 18}) '
                     f'rotate(-38)" font-size="10.5" text-anchor="end" '
                     f'fill="{INK}">{escape(str(label))}</text>')

    parts.append("</svg>")
    return "".join(parts)


def heatmap(rows: list[str], columns: list[str], values: list[list[float]],
            title: str, subtitle: str = "", cell: int = 64) -> str:
    """Grid of signed values (sources × targets), teal for positive, grey negative."""
    if not rows or not columns or len(values) != len(rows):
        raise ValueError("heatmap needs rows, columns and a matching matrix")

    left, top, right, bottom = 132, 92, 40, 46
    width = left + cell * len(columns) + right
    height = top + cell * len(rows) + bottom
    flat = [value for row in values for value in row if value is not None]
    limit = max((abs(value) for value in flat), default=1.0) or 1.0

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}" font-family="Helvetica, Arial, sans-serif">',
        f'<rect width="{width}" height="{height}" fill="#ffffff"/>',
        f'<text x="{left - 60}" y="30" font-size="15" font-weight="600" fill="{INK}">'
        f'{escape(title)}</text>',
    ]
    if subtitle:
        parts.append(f'<text x="{left - 60}" y="48" font-size="11" fill="{MUTED}">'
                     f'{escape(subtitle)}</text>')

    for col_index, column in enumerate(columns):
        x = left + cell * (col_index + 0.5)
        parts.append(f'<text transform="translate({x:.1f},{top - 10}) rotate(-40)" '
                     f'font-size="10.5" text-anchor="start" fill="{INK}">'
                     f'{escape(str(column))}</text>')
    for row_index, row in enumerate(rows):
        y = top + cell * (row_index + 0.5)
        parts.append(f'<text x="{left - 12}" y="{y + 4:.1f}" font-size="11" '
                     f'text-anchor="end" fill="{INK}">{escape(str(row))}</text>')

    for row_index, row in enumerate(values):
        for col_index, value in enumerate(row):
            x = left + cell * col_index
            y = top + cell * row_index
            if value is None or (isinstance(value, float) and math.isnan(value)):
                parts.append(f'<rect x="{x}" y="{y}" width="{cell}" height="{cell}" '
                             f'fill="#f1f5f9" stroke="#ffffff" stroke-width="1.5"/>')
                continue
            strength = min(1.0, abs(value) / limit)
            colour = POSITIVE if value >= 0 else "#b25b1f"
            opacity = 0.12 + 0.70 * strength
            parts.append(f'<rect x="{x}" y="{y}" width="{cell}" height="{cell}" '
                         f'fill="{colour}" fill-opacity="{opacity:.2f}" '
                         f'stroke="#ffffff" stroke-width="1.5"/>')
            parts.append(f'<text x="{x + cell / 2:.1f}" y="{y + cell / 2 + 4:.1f}" '
                         f'font-size="11" text-anchor="middle" fill="{INK}">'
                         f'{value:.2f}</text>')

    parts.append(f'<text x="{left}" y="{height - 12}" font-size="10" fill="{MUTED}">'
                 f'z 越大越靠近（正=靠近，负=疏远）</text>')
    parts.append("</svg>")
    return "".join(parts)
