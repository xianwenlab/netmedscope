"""Flask front end: upload a network plus gene sets, screen, download CSV.

Jobs run in a background thread and publish their state through ``/api/job/<id>``.
NetMedPy spawns worker processes for distance matrices, so this module must only
ever be imported (never ``python -c``-style executed) and its entry point stays
behind the ``__main__`` guard.
"""
from __future__ import annotations

import io
import sys
import tempfile
import threading
import time
import traceback
import uuid
from pathlib import Path

import pandas as pd
from flask import Flask, Response, jsonify, render_template, request, send_file

from . import charts, engine

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024

#: Bundled example inputs, next to the package so an unpacked copy just works.
EXAMPLES = Path(__file__).resolve().parent.parent / "examples"

JOBS: dict[str, dict] = {}
LOCK = threading.Lock()


def _parse_gene_file(path: Path) -> dict[str, set[str]]:
    frame = pd.read_csv(path, sep=None, engine="python", dtype=str, comment="#")
    columns = {c.lower(): c for c in frame.columns}
    set_col = next((columns[k] for k in ("set", "chemical", "disease", "drug", "name")
                    if k in columns), frame.columns[0])
    gene_col = next((columns[k] for k in ("gene", "entrez", "entrez_id", "symbol", "gene_id")
                     if k in columns), frame.columns[-1])
    return engine.read_gene_sets(path, set_col, gene_col)


def _run_job(job_id: str, workdir: Path, options: dict) -> None:
    job = JOBS[job_id]
    try:
        job.update(state="running", message="读取文件")
        graph = engine.read_edge_list(workdir / "network.csv",
                                      options["source_col"], options["target_col"],
                                      options["weight_col"], options["min_weight"])
        drugs = _parse_gene_file(workdir / "drugs.csv")
        diseases = _parse_gene_file(workdir / "diseases.csv")

        job["message"] = "构建分析子网"
        sub = engine.focus_subgraph(graph, {**drugs, **diseases}, options["max_nodes"])
        drugs, drugs_report = engine.keep_known(sub, drugs)
        diseases, diseases_report = engine.keep_known(sub, diseases)

        job["message"] = f"计算 {options['metric']} 距离矩阵"
        matrix, info = engine.distance_matrix(sub, options["metric"],
                                              workdir / "cache",
                                              reset=options["reset"],
                                              n_processors=options["processors"])
        job["message"] = "随即开展筛选（置换检验）"
        tables = engine.proximity_table(sub, matrix, drugs, diseases,
                                        null_model=options["null_model"],
                                        n_iter=options["iterations"],
                                        n_procs=options["processors"],
                                        score=options.get("score", "proximity"),
                                        symmetric=bool(options.get("symmetric")))
        spec = engine.SCORES[options.get("score", "proximity")]
        tidy = engine.long_form(tables, options.get("score", "proximity"))
        tidy.to_csv(workdir / "proximity.csv", index=False, encoding="utf-8-sig")
        # Raw separation has no null model, so it has no z column at all.
        ranking = "z_score" if "z_score" in tables else spec["value"]
        wide = tables[ranking]
        wide.to_csv(workdir / "proximity_wide.csv", encoding="utf-8-sig")

        job["message"] = "计算 LCC 网络定位显著性"
        lcc = engine.lcc_table(sub, {**drugs, **diseases},
                               null_model=options["null_model"],
                               n_iter=options["iterations"])
        lcc.to_csv(workdir / "lcc.csv", index=False, encoding="utf-8-sig")

        job["message"] = "生成图表"
        pairs = [f"{row.source} → {row.target}" for row in tidy.itertuples()]
        settings = (f"{options.get('score', 'proximity')} · {options['metric']} · "
                    f"{options['null_model']} · {options['iterations']} 次置换")
        (workdir / "proximity.svg").write_text(
            charts.bar_chart(pairs, tidy[ranking].tolist(),
                             f"{spec['label']} 逐对分数", settings),
            encoding="utf-8")
        (workdir / "heatmap.svg").write_text(
            charts.heatmap(list(wide.index), list(wide.columns),
                           wide.values.tolist(), f"{spec['label']} 热图",
                           "行=药物靶点集，列=疾病基因集"),
            encoding="utf-8")
        (workdir / "lcc.svg").write_text(
            charts.bar_chart([str(name) for name in lcc["set"]],
                             [float(value) for value in lcc["z_score"]],
                             "LCC 显著性 z 分数", settings),
            encoding="utf-8")

        job.update(state="done",
                   message=f"{len(tidy)} 对组合 · {len(lcc)} 个基因集",
                   summary=_conclusion(tidy, lcc),
                   finished_at=time.strftime("%Y-%m-%d %H:%M:%S"),
                   score=options.get("score", "proximity"),
                   ranking=ranking,
                   workdir=str(workdir),
                   graph={"nodes": sub.number_of_nodes(),
                          "edges": sub.number_of_edges()},
                   matrix={"metric": info.metric, "cached": info.cached,
                           "seconds": info.seconds},
                   coverage={"drugs": drugs_report, "diseases": diseases_report},
                   rows=tidy.head(200).to_dict(orient="records"),
                   columns=list(tidy.columns),
                   lcc_rows=lcc.head(200).to_dict(orient="records"),
                   lcc_columns=list(lcc.columns),
                   charts={name: f"/api/job/{job_id}/chart/{name}.svg"
                           for name in ("proximity", "heatmap", "lcc")})
    except Exception as exc:                        # noqa: BLE001
        job.update(state="error", message=str(exc),
                   traceback=traceback.format_exc()[-1500:])


def _start_job(upload_dir: Path, options: dict) -> str:
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"state": "queued", "message": "排队中", "started": time.time(),
                    "options": options}
    threading.Thread(target=_run_job, args=(job_id, upload_dir, options),
                     daemon=True).start()
    return job_id


@app.get("/")
def index():
    return render_template("index.html", metrics=engine.METRICS,
                           nulls=engine.NULL_MODELS, scores=engine.SCORES)


@app.post("/api/run")
def api_run():
    upload_dir = Path(tempfile.mkdtemp(prefix="netmedscope_"))
    for field in ("network", "drugs", "diseases"):
        upload = request.files.get(field)
        if upload is None or not upload.filename:
            return jsonify(error=f"缺少文件：{field}"), 400
        upload.save(upload_dir / f"{field}.csv")

    options = {
        "source_col": request.form.get("source_col") or "EntrezA",
        "target_col": request.form.get("target_col") or "EntrezB",
        "weight_col": request.form.get("weight_col") or None,
        "min_weight": float(request.form.get("min_weight") or 0) or None,
        "metric": request.form.get("metric") or "shortest_path",
        "reset": float(request.form.get("reset") or 0.2),
        "null_model": request.form.get("null_model") or "log_binning",
        "score": request.form.get("score") or "proximity",
        "symmetric": bool(request.form.get("symmetric")),
        "iterations": int(request.form.get("iterations") or 500),
        "processors": int(request.form.get("processors") or 1),
        "max_nodes": int(request.form.get("max_nodes") or 400),
    }
    return jsonify(job_id=_start_job(upload_dir, options))


@app.post("/api/run-example")
def api_run_example():
    """Run the bundled example, so the page is usable without any files."""
    needed = ("network.csv", "drugs.csv", "diseases.csv")
    missing = [name for name in needed if not (EXAMPLES / name).is_file()]
    if missing:
        return jsonify(error=f"示例数据缺失：{missing}"), 404

    workdir = Path(tempfile.mkdtemp(prefix="netmedscope_example_"))
    for name in needed:
        (workdir / name).write_bytes((EXAMPLES / name).read_bytes())

    options = {
        "source_col": "EntrezA", "target_col": "EntrezB",
        "weight_col": None, "min_weight": None,
        "metric": request.form.get("metric") or "shortest_path",
        "reset": 0.2,
        "null_model": request.form.get("null_model") or "uniform",
        "score": request.form.get("score") or "proximity",
        "symmetric": False,
        "iterations": int(request.form.get("iterations") or 200),
        "processors": 1,
        "max_nodes": 800,
    }
    return jsonify(job_id=_start_job(workdir, options))


@app.get("/api/job/<job_id>")
def api_job(job_id: str):
    job = JOBS.get(job_id)
    if job is None:
        return jsonify(error="unknown job"), 404
    return jsonify(job)


@app.get("/api/job/<job_id>/proximity.csv")
def api_download(job_id: str):
    job = JOBS.get(job_id)
    if job is None:
        return jsonify(error="unknown job"), 404
    workdir = job.get("workdir")
    result = Path(workdir) / "proximity.csv" if workdir else None
    if result is None or not result.is_file():
        return jsonify(error="结果文件还没生成"), 404
    return send_file(io.BytesIO(result.read_bytes()), as_attachment=True,
                     download_name=f"proximity-{job_id}.csv",
                     mimetype="text/csv")


@app.get("/api/job/<job_id>/lcc.csv")
def api_download_lcc(job_id: str):
    job = JOBS.get(job_id)
    if job is None:
        return jsonify(error="unknown job"), 404
    workdir = job.get("workdir")
    result = Path(workdir) / "lcc.csv" if workdir else None
    if result is None or not result.is_file():
        return jsonify(error="LCC 结果还没生成"), 404
    return send_file(io.BytesIO(result.read_bytes()), as_attachment=True,
                     download_name=f"lcc-{job_id}.csv", mimetype="text/csv")


@app.get("/api/job/<job_id>/chart/<name>.svg")
def api_chart(job_id: str, name: str):
    if name not in ("proximity", "heatmap", "lcc"):
        return jsonify(error="unknown chart"), 404
    job = JOBS.get(job_id)
    if job is None:
        return jsonify(error="unknown job"), 404
    workdir = job.get("workdir")
    chart = Path(workdir) / f"{name}.svg" if workdir else None
    if chart is None or not chart.is_file():
        return jsonify(error="图表还没生成"), 404
    return send_file(io.BytesIO(chart.read_bytes()), mimetype="image/svg+xml",
                     download_name=f"{name}-{job_id}.svg")


def _conclusion(tidy, lcc) -> str:
    """One sentence a non-programmer can read out loud, without over-claiming.

    Sorting is by z ascending, so the first row is the best-ranked pair.  When
    every z is positive that pair is still farther than chance, and saying
    "closest" there would mislead the reader -- so the wording follows the sign.
    """
    bits = []
    if len(tidy):
        top = tidy.iloc[0]
        if "z_score" in tidy.columns:
            z = float(top["z_score"])
            if z < 0:
                bits.append(f"与疾病最接近的是「{top['source']} → {top['target']}」"
                            f"（z = {z:.2f}，比随机更近）")
            else:
                bits.append(f"没有任何一对比随机更近；排名最靠前的是"
                            f"「{top['source']} → {top['target']}」"
                            f"（z = {z:.2f}，仍比随机更远）")
        else:
            bits.append(f"分离度最小的一对是「{top['source']} → {top['target']}」"
                        f"（{float(top['raw_separation']):.2f}，越小越集中）")
    if len(lcc):
        best = lcc.sort_values("z_score", ascending=False).iloc[0]
        z_lcc = float(best["z_score"])
        qualifier = "比随机更聚集" if z_lcc > 0 else "并不比随机更聚集"
        bits.append(f"最像模块的基因集是「{best['set']}」"
                    f"（最大连通分量 {int(best['lcc_size'])} 个基因，"
                    f"z = {z_lcc:.2f}，{qualifier}）")
    return "；".join(bits) + "。" if bits else "本次没有产生可报告的结果。"


#: Column names in the shared report, so a reader does not need to know the API.
REPORT_HEADERS = {
    "source": "药物/靶点集", "target": "疾病基因集", "set": "基因集",
    "z_score": "z 分数", "raw_amspl": "平均最近距离",
    "raw_separation": "分离度", "p_value_single_tail": "单尾 p 值",
    "p_value": "p 值", "genes_in_network": "网内基因数",
    "lcc_size": "最大连通分量", "null_model": "零模型",
    "iterations": "置换次数",
}


def _table_html(columns: list[str], rows: list[dict], limit: int = 20) -> str:
    from html import escape

    head = "".join(f"<th>{escape(REPORT_HEADERS.get(c, c))}</th>" for c in columns)
    body = []
    for row in rows[:limit]:
        cells = []
        for column in columns:
            value = row.get(column)
            text = f"{value:.3f}" if isinstance(value, float) else str(value)
            cells.append(f"<td>{escape(text)}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    return (f"<table><thead><tr>{head}</tr></thead>"
            f"<tbody>{''.join(body)}</tbody></table>")


def _report_html(job: dict, job_id: str) -> str:
    """Self-contained report: charts are inlined, so one file is enough."""
    from html import escape

    workdir = Path(job["workdir"])
    charts_html = []
    for name, title in (("proximity", "逐对分数"), ("heatmap", "热图"),
                        ("lcc", "LCC 显著性")):
        path = workdir / f"{name}.svg"
        if path.is_file():
            charts_html.append(f"<h3>{title}</h3>"
                               f"{path.read_text(encoding='utf-8')}")

    options = job.get("options", {})
    params = "".join(
        f"<tr><th>{escape(str(key))}</th><td>{escape(str(value))}</td></tr>"
        for key, value in options.items())
    coverage = job.get("coverage", {})
    covered = "；".join(
        f"{kind}: " + "、".join(f"{name} {count}" for name, count in group.items())
        for kind, group in coverage.items())

    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<title>网络医学分析报告 {escape(job_id)}</title>
<style>
 body{{font-family:-apple-system,'Segoe UI','Microsoft YaHei',sans-serif;
       max-width:900px;margin:32px auto;padding:0 20px;color:#1f2937;line-height:1.7}}
 h1{{font-size:21px;margin:0 0 4px}} h2{{font-size:15px;margin:26px 0 8px}}
 h3{{font-size:13px;margin:18px 0 6px;color:#475569}}
 .meta{{color:#64748b;font-size:12px}}
 .summary{{padding:12px 14px;background:#ecfdf5;border-left:3px solid #0f766e;
           font-size:13.5px;color:#064e3b}}
 table{{border-collapse:collapse;width:100%;font-size:12.5px;margin-top:8px}}
 th,td{{border-bottom:1px solid #e5e7eb;padding:6px 8px;text-align:left}}
 th{{background:#f1f5f9;font-weight:600}}
 svg{{max-width:100%;height:auto;border:1px solid #e5e7eb;border-radius:6px}}
 footer{{margin-top:30px;color:#64748b;font-size:11.5px}}
</style></head><body>
<h1>网络医学分析报告</h1>
<div class="meta">任务 {escape(job_id)} · 生成于 {escape(str(job.get('finished_at') or ''))}
 · 计算引擎 NetMedPy，平台负责流程、出图与报告</div>

<h2>一句话结论</h2>
<div class="summary">{escape(job.get('summary', '（无）'))}</div>

<h2>运行参数</h2>
<table><tbody>{params}</tbody></table>
<div class="meta">子网 {job.get('graph', {}).get('nodes', '?')} 节点 /
 {job.get('graph', {}).get('edges', '?')} 边；距离矩阵
 {escape(str(job.get('matrix', {}).get('metric', '')))}，
 {job.get('matrix', {}).get('seconds', '?')} 秒；基因覆盖：{escape(covered)}</div>

<h2>邻近度/分离度结果（前 20 行）</h2>
{_table_html(job.get('columns', []), job.get('rows', []))}

<h2>LCC 网络定位（前 20 行）</h2>
{_table_html(job.get('lcc_columns', []), job.get('lcc_rows', []))}

<h2>图表</h2>
{''.join(charts_html)}

<footer>本报告由「网络医学分析平台」自动生成。分析方法、零模型与置换检验来自 NetMedPy
（Aldana et al., Bioinformatics 2025），平台未修改其算法。完整数据见同目录 CSV。</footer>
</body></html>"""


@app.get("/api/job/<job_id>/report.html")
def api_report(job_id: str):
    job = JOBS.get(job_id)
    if job is None:
        return jsonify(error="unknown job"), 404
    if job.get("state") != "done":
        return jsonify(error="任务还没完成"), 409
    return Response(_report_html(job, job_id), mimetype="text/html")


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8300
    app.run(host="127.0.0.1", port=port, debug=False)
