"""NetMedPy Platform: a reproducible front end for network-medicine screening."""
from __future__ import annotations

__version__ = "0.1.0"

from .engine import (  # noqa: F401
    METRICS,
    NULL_MODELS,
    PlatformError,
    distance_matrix,
    keep_known,
    lcc_table,
    long_form,
    proximity_table,
    read_edge_list,
    read_gene_sets,
)
