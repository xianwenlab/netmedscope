"""Analysis engine: a thin, reproducible layer over NetMedPy.

NetMedPy does the science (four distance metrics, four null models, LCC
significance, screening).  This module only adds what a platform needs around it:
reading files, caching distance matrices, and returning tidy tables.

One platform-specific detail matters on Windows: NetMedPy computes distance
matrices in a ``spawn`` process pool, so every entry point that can reach
:func:`distance_matrix` must live behind ``if __name__ == "__main__":``.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd

import netmedpy

#: The four metrics NetMedPy implements.  ``custom`` is left out on purpose: a
#: callback cannot be cached or reproduced across machines.
METRICS = {
    "shortest_path": "最短路径（AMSPL）",
    "random_walk": "随机游走",
    "biased_random_walk": "有偏随机游走",
    "communicability": "传播性 Communicability",
}

#: The four null models, used both for proximity and for LCC significance.
NULL_MODELS = {
    "degree_match": "度完美匹配（degree match）",
    "log_binning": "度对数分箱（log binning）",
    "strength_binning": "强度对数分箱（strength binning）",
    "uniform": "均匀抽样（uniform）",
}

#: NetMedPy exposes three screening scores.  They differ in what is compared and
#: in which columns come back: ``separation`` has no null model at all, so no
#: z score or p value exists for it -- only the raw value.
SCORES = {
    "proximity": {
        "label": "邻近度 proximity",
        "value": "raw_amspl",
        "properties": ("z_score", "raw_amspl", "p_value_single_tail"),
    },
    "separation": {
        "label": "分离度 separation",
        "value": "raw_separation",
        "properties": ("raw_separation",),
    },
    "separation_z_score": {
        "label": "分离度 z 分数 separation (z)",
        "value": "raw_separation",
        "properties": ("z_score", "raw_separation", "p_value_single_tail"),
    },
}


class PlatformError(RuntimeError):
    """Raised for problems the user can fix: bad input, empty intersection."""


# --------------------------------------------------------------------- inputs
def read_edge_list(path: str | Path, source_col: str = "EntrezA",
                   target_col: str = "EntrezB", weight_col: str | None = None,
                   min_weight: float | None = None) -> nx.Graph:
    """Read a two-column edge list (CSV/TSV, comma or tab) into a simple graph."""
    path = Path(path)
    if not path.is_file():
        raise PlatformError(f"找不到网络文件：{path}")
    separator = "\t" if path.suffix.lower() in (".tsv", ".txt") else ","
    frame = pd.read_csv(path, sep=separator, dtype=str, comment="#")
    missing = {source_col, target_col} - set(frame.columns)
    if missing:
        raise PlatformError(f"网络文件缺少列：{sorted(missing)}；现有列 {list(frame.columns)}")

    graph = nx.Graph()
    if weight_col and weight_col in frame.columns:
        weights = pd.to_numeric(frame[weight_col], errors="coerce")
        for a, b, w in zip(frame[source_col], frame[target_col], weights):
            if pd.isna(w):
                continue
            if min_weight is not None and float(w) < float(min_weight):
                continue
            graph.add_edge(str(a).strip(), str(b).strip(), weight=float(w))
    else:
        for a, b in zip(frame[source_col], frame[target_col]):
            if pd.isna(a) or pd.isna(b):
                continue
            graph.add_edge(str(a).strip(), str(b).strip())
    if graph.number_of_edges() == 0:
        raise PlatformError("网络里没有任何边，检查列名与分隔符。")
    return graph


def read_gene_sets(path: str | Path, set_col: str | None = None,
                   gene_col: str | None = None) -> dict[str, set[str]]:
    """Read ``set,gene`` rows into ``{set name: {genes}}``.

    Column names are detected when not given, so one CLI can read a file whose
    columns are ``chemical,entrez_id`` and another whose are ``disease,gene``
    without the caller repeating the layout for every input.
    """
    path = Path(path)
    if not path.is_file():
        raise PlatformError(f"找不到基因集文件：{path}")
    separator = "\t" if path.suffix.lower() in (".tsv", ".txt") else ","
    frame = pd.read_csv(path, sep=separator, dtype=str, comment="#")

    columns = {name.lower(): name for name in frame.columns}
    # A caller-supplied column that is not in this file means "use the layout I
    # described" was wrong for this file; detecting is friendlier than failing.
    if not set_col or set_col not in frame.columns:
        set_col = next((columns[key] for key in
                        ("set", "chemical", "disease", "drug", "name", "group")
                        if key in columns), None)
    if not gene_col or gene_col not in frame.columns:
        gene_col = next((columns[key] for key in
                         ("gene", "entrez_id", "entrez", "symbol", "gene_id")
                         if key in columns), None)
    if set_col is None or gene_col is None \
            or set_col not in frame.columns or gene_col not in frame.columns:
        raise PlatformError(
            f"基因集文件 {path.name} 的列无法识别：需要“集合名+基因”两列，"
            f"现有列 {list(frame.columns)}")
    groups: dict[str, set[str]] = {}
    for name, gene in zip(frame[set_col], frame[gene_col]):
        if pd.isna(name) or pd.isna(gene):
            continue
        groups.setdefault(str(name).strip(), set()).add(str(gene).strip())
    return {name: genes for name, genes in groups.items() if genes}


def keep_known(graph: nx.Graph, groups: dict[str, set[str]],
               minimum: int = 1) -> tuple[dict[str, set[str]], dict[str, int]]:
    """Drop genes that are not in the network; report how many survived."""
    nodes = set(graph.nodes)
    kept, report = {}, {}
    for name, genes in groups.items():
        inside = genes & nodes
        report[name] = len(inside)
        if len(inside) >= minimum:
            kept[name] = inside
    if not kept:
        raise PlatformError("所有基因集与网络都没有交集，检查节点命名是否一致（Entrez/Symbol）。")
    return kept, report


def focus_subgraph(graph: nx.Graph, groups: dict[str, set[str]],
                   max_nodes: int = 600) -> nx.Graph:
    """Network slice that keeps every gene set reachable.

    Taking the genes of interest plus their neighbours and then only the largest
    component silently dropped whole sets: a disease set sitting across a gap
    vanished and the run reported "no overlap".  Here every component that holds
    at least one gene of interest is kept, and the size cap never discards such a
    component (it only trims the highest-degree nodes beyond the cap).
    """
    if graph.number_of_nodes() == 0:
        raise PlatformError("网络为空。")
    base = graph.subgraph(max(nx.connected_components(graph), key=len)).copy()
    focus = set().union(*groups.values()) if groups else set()
    focus &= set(base.nodes)
    if not focus:
        raise PlatformError("所有基因都不在网络的最大连通分量里，"
                            "检查节点命名是否一致（Entrez/Symbol）。")

    # Keep the paths BETWEEN the genes of interest, so the slice is connected (a
    # hard requirement of NetMedPy) without discarding any set: taking "focus plus
    # neighbours, then the largest component" dropped sets that sat further along
    # the network, and the run then reported "no overlap".
    ordered = sorted(focus)
    spine: set[str] = set(ordered)
    for left, right in zip(ordered, ordered[1:]):
        try:
            spine.update(nx.shortest_path(base, left, right))
        except nx.NetworkXNoPath:
            continue                      # different component: reported as uncovered

    keep = set(spine)
    for node in list(spine):              # one hop of context around the spine
        keep.update(base.neighbors(node))

    if len(keep) > max_nodes:
        keep = set(spine)                 # drop context before dropping a gene
    if len(keep) > max_nodes:
        degree = sorted(base.subgraph(keep).degree,
                        key=lambda item: item[1], reverse=True)
        trimmed = {node for node, _ in degree[:max_nodes]}
        keep = trimmed | (focus & keep)   # the genes themselves always stay
        keep |= set(spine) & keep

    sub = base.subgraph(keep).copy()
    # NetMedPy needs one component; the spine already connects everything that can
    # be connected, so keep the component holding the most genes of interest.
    parts = list(nx.connected_components(sub))
    best = max(parts, key=lambda part: (len(part & focus), len(part)))
    return sub.subgraph(best).copy()


# ----------------------------------------------------------------- the matrix
@dataclass
class MatrixInfo:
    metric: str
    reset: float
    nodes: int
    edges: int
    seconds: float
    cached: bool
    path: str
    extra: dict = field(default_factory=dict)


def _signature(graph: nx.Graph, metric: str, reset: float) -> str:
    digest = hashlib.sha256()
    digest.update(f"{metric}|{reset}|{graph.number_of_nodes()}|".encode())
    for a, b in sorted((min(u, v), max(u, v)) for u, v in graph.edges()):
        digest.update(f"{a}-{b};".encode())
    return digest.hexdigest()[:16]


def distance_matrix(graph: nx.Graph, metric: str, cache_dir: str | Path,
                    reset: float = 0.2, n_processors: int = 1,
                    force: bool = False) -> tuple[object, MatrixInfo]:
    """Return a cached all-pairs distance matrix for ``graph`` under ``metric``.

    The cache name carries a hash of the edge set, so editing the network or
    switching metric never reuses the wrong matrix.
    """
    if metric not in METRICS:
        raise PlatformError(f"未知距离指标：{metric}；可选 {list(METRICS)}")
    cache = Path(cache_dir)
    cache.mkdir(parents=True, exist_ok=True)
    stem = f"{metric}-{_signature(graph, metric, reset)}"
    # save_distances uses numpy.savez_compressed, which appends ".npz" to any name
    # that lacks it -- naming the store ".npz" here is what makes the cache hit.
    store = cache / f"{stem}.npz"
    meta_file = cache / f"{stem}.json"

    if store.is_file() and not force:
        start = time.time()
        matrix = netmedpy.load_distances(str(store))
        meta = json.loads(meta_file.read_text(encoding="utf-8")) if meta_file.is_file() else {}
        return matrix, MatrixInfo(metric, reset, graph.number_of_nodes(),
                                  graph.number_of_edges(), round(time.time() - start, 2),
                                  True, str(store), meta)

    started = time.time()
    matrix = netmedpy.all_pair_distances(graph, distance=metric, reset=reset,
                                         n_processors=n_processors)
    seconds = round(time.time() - started, 2)
    netmedpy.save_distances(matrix, str(store))
    meta = {"metric": metric, "reset": reset, "nodes": graph.number_of_nodes(),
            "edges": graph.number_of_edges(), "seconds": seconds}
    meta_file.write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return matrix, MatrixInfo(metric, reset, graph.number_of_nodes(),
                              graph.number_of_edges(), seconds, False, str(store), meta)


# ------------------------------------------------------------------- analyses
def lcc_table(graph: nx.Graph, gene_sets: dict[str, set[str]],
              null_model: str = "log_binning", n_iter: int = 1000) -> pd.DataFrame:
    """LCC size and its significance for every gene set (network localization)."""
    rows = []
    for name, genes in gene_sets.items():
        data = netmedpy.lcc_significance(graph, genes, null_model=null_model,
                                         n_iter=n_iter)
        rows.append({
            "set": name,
            "genes_in_network": len(genes),
            "lcc_size": data.get("lcc_size"),
            "z_score": data.get("z_score"),
            "p_value": data.get("p_val"),
            "null_model": null_model,
            "iterations": n_iter,
        })
    return pd.DataFrame(rows)


def proximity_table(graph: nx.Graph, distance_matrix, sources: dict[str, set[str]],
                    targets: dict[str, set[str]], null_model: str = "log_binning",
                    n_iter: int = 1000, n_procs: int | None = None,
                    score: str = "proximity",
                    symmetric: bool = False,
                    properties: tuple[str, ...] | None = None,
                    ) -> dict[str, pd.DataFrame]:
    """Screen every source/target pair with one of NetMedPy's three scores.

    ``symmetric=True`` switches to NetMedPy's symmetric proximity P_s(A, B); the
    default asymmetric score answers the drug-repurposing question "how close are
    the targets to the disease module".
    """
    if score not in SCORES:
        raise PlatformError(f"未知评分：{score}；可选 {list(SCORES)}")
    spec = SCORES[score]
    columns = properties or spec["properties"]
    tables = netmedpy.screening(sources, targets, graph, distance_matrix,
                                score=score, properties=list(columns),
                                null_model=null_model, n_iter=n_iter,
                                symmetric=symmetric, n_procs=n_procs)
    return {key: pd.DataFrame(value) for key, value in tables.items()}


def long_form(result: dict[str, pd.DataFrame], score: str = "proximity",
              ) -> pd.DataFrame:
    """Flatten the property tables into one tidy frame, best pair first.

    For proximity and separation-z the ranking column is ``z_score``, and because
    the z is measured as (observed - random)/sigma a *negative* value means the
    sets are closer than chance, so the frame is sorted ascending.  Raw
    separation has no null model, so it is sorted ascending on its own value.
    """
    spec = SCORES.get(score)
    if spec is None:
        raise PlatformError(f"未知评分：{score}")
    value_column = spec["value"]

    if "z_score" in result:
        frame = result["z_score"].stack().rename("z_score").reset_index()
        frame.columns = ["source", "target", "z_score"]
        order = "z_score"
    else:
        if value_column not in result:
            raise PlatformError(f"结果里没有 {value_column}")
        frame = result[value_column].stack().rename(value_column).reset_index()
        frame.columns = ["source", "target", value_column]
        order = value_column

    index = pd.MultiIndex.from_frame(frame[["source", "target"]])
    for key in (value_column, "p_value_single_tail", "p_value_double_tail"):
        if key == order or key not in result:
            continue
        frame[key] = result[key].stack().reindex(index).values

    ordered = ["source", "target"] + (["z_score"] if "z_score" in frame else [])
    rest = [column for column in frame.columns if column not in ordered]
    return frame[ordered + rest].sort_values(order).reset_index(drop=True)
