"""Command-line entry point.

Every run writes the same three artefacts next to each other, so a result can be
re-derived later: ``proximity.csv`` (tidy), ``proximity_wide.csv`` (matrix view),
``lcc.csv`` and ``run.json`` with the inputs' hashes, options and timings.

Windows note: NetMedPy computes distance matrices in a spawn process pool, so the
work has to sit behind ``if __name__ == "__main__":`` -- otherwise each worker
re-imports this module and the pool dies with BrokenProcessPool.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import sys
import time
from pathlib import Path

import netmedpy

from . import engine


def _sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _package_version(name: str) -> str:
    """NetMedPy does not expose ``__version__``; read it from the metadata."""
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def _subset(graph, nodes: set[str]):
    """Induced subgraph on ``nodes`` and its immediate neighbours."""
    import networkx as nx

    keep = set(nodes)
    for node in nodes:
        if node in graph:
            keep.update(graph.neighbors(node))
    sub = graph.subgraph(keep & set(graph.nodes)).copy()
    if sub.number_of_nodes() == 0:
        raise engine.PlatformError("选定的基因都不在网络里。")
    largest = max(nx.connected_components(sub), key=len)
    return sub.subgraph(largest).copy()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="netmed-platform",
        description="网络医学分析平台：邻近度/分离度筛选、LCC 显著性、距离矩阵缓存")
    parser.add_argument("--network", required=True, help="边列表 CSV/TSV")
    parser.add_argument("--source-col", default="EntrezA")
    parser.add_argument("--target-col", default="EntrezB")
    parser.add_argument("--weight-col", default=None)
    parser.add_argument("--min-weight", type=float, default=None)

    parser.add_argument("--drugs", help="药物–靶点基因集文件（set,gene 两列）")
    parser.add_argument("--diseases", help="疾病基因集文件（set,gene 两列）")
    parser.add_argument("--set-col", default=None,
                        help="集合名列，省略则自动识别（set/chemical/disease…）")
    parser.add_argument("--gene-col", default=None,
                        help="基因列名，省略则自动识别（gene/entrez_id/symbol…）")

    parser.add_argument("--metric", default="shortest_path", choices=list(engine.METRICS))
    parser.add_argument("--score", default="proximity", choices=list(engine.SCORES),
                        help="proximity | separation | separation_z_score")
    parser.add_argument("--reset", type=float, default=0.2, help="随机游走的重启概率")
    parser.add_argument("--null", default="log_binning", choices=list(engine.NULL_MODELS))
    parser.add_argument("--iterations", type=int, default=1000)
    parser.add_argument("--symmetric", action="store_true",
                        help="使用对称邻近度 P_s(A,B)（默认不对称）")
    parser.add_argument("--processors", type=int, default=1,
                        help="距离矩阵的进程数；Windows 下建议 1")
    parser.add_argument("--max-nodes", type=int, default=600,
                        help="为控制耗时，把网络限制在靶点/疾病基因及其邻居的 LCC 内")
    parser.add_argument("--out", default="results")
    parser.add_argument("--cache", default=None, help="距离矩阵缓存目录，默认 <out>/cache")
    parser.add_argument("--skip-lcc", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    cache = Path(args.cache) if args.cache else out / "cache"
    started = time.time()

    graph = engine.read_edge_list(args.network, args.source_col, args.target_col,
                                  args.weight_col, args.min_weight)
    print(f"网络：{graph.number_of_nodes()} 个节点，{graph.number_of_edges()} 条边")

    drugs = engine.read_gene_sets(args.drugs, args.set_col, args.gene_col)
    diseases = engine.read_gene_sets(args.diseases, args.set_col, args.gene_col)
    print(f"药物集合 {len(drugs)} 个，疾病集合 {len(diseases)} 个")

    focus = set().union(*drugs.values(), *diseases.values())
    sub = engine.focus_subgraph(graph, {"drugs": focus}, args.max_nodes)
    print(f"分析子网：{sub.number_of_nodes()} 个节点，{sub.number_of_edges()} 条边")

    drugs, drug_report = engine.keep_known(sub, drugs)
    diseases, disease_report = engine.keep_known(sub, diseases)

    matrix, info = engine.distance_matrix(sub, args.metric, cache, reset=args.reset,
                                          n_processors=args.processors)
    print(f"距离矩阵：{args.metric} {'缓存命中' if info.cached else '新建'}，{info.seconds}s")

    tables = engine.proximity_table(sub, matrix, drugs, diseases,
                                    null_model=args.null, n_iter=args.iterations,
                                    n_procs=args.processors, score=args.score,
                                    symmetric=args.symmetric)
    tidy = engine.long_form(tables, args.score)
    tidy.to_csv(out / f"{args.score}.csv", index=False, encoding="utf-8-sig")
    # Raw separation has no null model, so there is no z table to write.
    ranking = "z_score" if "z_score" in tables else engine.SCORES[args.score]["value"]
    tables[ranking].to_csv(out / f"{args.score}_wide.csv", encoding="utf-8-sig")

    lcc = None
    if not args.skip_lcc:
        lcc = engine.lcc_table(sub, {**drugs, **diseases}, null_model=args.null,
                               n_iter=args.iterations)
        lcc.to_csv(out / "lcc.csv", index=False, encoding="utf-8-sig")

    payload = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "seconds": round(time.time() - started, 2),
        "engine": {"netmedpy": _package_version("netmedpy"),
                   "python": platform.python_version()},
        "inputs": {
            "network": {"path": str(args.network), "sha256": _sha256(args.network)},
            "drugs": {"path": str(args.drugs), "sha256": _sha256(args.drugs)},
            "diseases": {"path": str(args.diseases), "sha256": _sha256(args.diseases)},
        },
        "options": {"metric": args.metric, "reset": args.reset, "null_model": args.null,
                    "score": args.score, "ranking_column": ranking,
                    "iterations": args.iterations, "symmetric": bool(args.symmetric)},
        "graph": {"nodes": sub.number_of_nodes(), "edges": sub.number_of_edges()},
        "matrix": {"metric": info.metric, "cached": info.cached, "seconds": info.seconds,
                   "path": info.path},
        "coverage": {"drugs": drug_report, "diseases": disease_report},
        "pairs": len(tidy),
    }
    (out / "run.json").write_text(json.dumps(payload, ensure_ascii=False, indent=1),
                                  encoding="utf-8")
    print(f"完成：{len(tidy)} 对组合，输出目录 {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
