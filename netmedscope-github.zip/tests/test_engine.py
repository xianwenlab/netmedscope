"""Engine tests: file parsing, caching, and the numbers NetMedPy returns."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import networkx as nx

from netmedscope import engine


class InputTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="netmed_test_"))

    def test_reads_csv_edge_list(self):
        path = self.tmp / "net.csv"
        path.write_text("EntrezA,EntrezB\n1,2\n2,3\n1,3\n", encoding="utf-8")
        graph = engine.read_edge_list(path)
        self.assertEqual(graph.number_of_nodes(), 3)
        self.assertEqual(graph.number_of_edges(), 3)

    def test_reports_missing_columns(self):
        path = self.tmp / "bad.csv"
        path.write_text("a,b\n1,2\n", encoding="utf-8")
        with self.assertRaises(engine.PlatformError):
            engine.read_edge_list(path)

    def test_keeps_only_known_genes(self):
        graph = nx.path_graph(4)
        graph = nx.relabel_nodes(graph, {n: str(n) for n in graph.nodes})
        kept, report = engine.keep_known(graph, {"A": {"0", "1", "99"}})
        self.assertEqual(kept["A"], {"0", "1"})
        self.assertEqual(report["A"], 2)

    def test_rejects_gene_sets_without_overlap(self):
        graph = nx.path_graph(3)
        with self.assertRaises(engine.PlatformError):
            engine.keep_known(graph, {"A": {"x"}})


class DistanceTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="netmed_dist_"))
        self.graph = nx.path_graph(6)          # 0-1-2-3-4-5

    def test_shortest_path_matrix_matches_graph(self):
        matrix, info = engine.distance_matrix(self.graph, "shortest_path", self.tmp,
                                              n_processors=1)
        self.assertEqual(float(matrix.get(0, 5)), 5.0)
        self.assertFalse(info.cached)
        self.assertEqual(info.nodes, 6)

    def test_second_call_hits_the_cache(self):
        engine.distance_matrix(self.graph, "shortest_path", self.tmp, n_processors=1)
        _, info = engine.distance_matrix(self.graph, "shortest_path", self.tmp,
                                         n_processors=1)
        self.assertTrue(info.cached)
        self.assertLess(info.seconds, 5)

    def test_unknown_metric_is_rejected(self):
        with self.assertRaises(engine.PlatformError):
            engine.distance_matrix(self.graph, "cosine", self.tmp)


class ScreeningTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="netmed_screen_"))
        self.graph = nx.path_graph(8)
        self.matrix, _ = engine.distance_matrix(self.graph, "shortest_path", self.tmp,
                                                n_processors=1)

    def test_proximity_table_has_expected_shape_and_values(self):
        tables = engine.proximity_table(self.graph, self.matrix,
                                        {"drug": {0}}, {"disease": {7}},
                                        null_model="uniform", n_iter=100)
        self.assertIn("z_score", tables)
        self.assertEqual(tables["z_score"].shape, (1, 1))
        self.assertAlmostEqual(float(tables["raw_amspl"].iloc[0, 0]), 7.0, places=3)

    def test_long_form_is_tidy(self):
        tables = engine.proximity_table(self.graph, self.matrix,
                                        {"a": {0}, "b": {1}}, {"x": {7}},
                                        null_model="uniform", n_iter=50)
        tidy = engine.long_form(tables)
        self.assertEqual(list(tidy.columns)[:3], ["source", "target", "z_score"])
        self.assertIn("raw_amspl", tidy.columns)
        self.assertIn("p_value_single_tail", tidy.columns)
        self.assertEqual(len(tidy), 2)
        self.assertTrue(tidy["z_score"].notna().all())

    def test_proximity_ranks_closest_first(self):
        """z is (observed - random)/sd, so the most related pair has the smallest z."""
        tables = engine.proximity_table(self.graph, self.matrix,
                                        {"a": {0}}, {"near": {1}, "far": {7}},
                                        null_model="uniform", n_iter=200)
        tidy = engine.long_form(tables, "proximity")
        self.assertEqual(tidy.iloc[0]["target"], "near")
        self.assertLess(tidy.iloc[0]["z_score"], tidy.iloc[1]["z_score"])

    def test_raw_separation_has_no_null_model_columns(self):
        tables = engine.proximity_table(self.graph, self.matrix,
                                        {"a": {0}}, {"b": {7}},
                                        null_model="uniform", n_iter=50,
                                        score="separation")
        self.assertIn("raw_separation", tables)
        self.assertNotIn("z_score", tables)      # NetMedPy has no null here
        tidy = engine.long_form(tables, "separation")
        self.assertEqual(list(tidy.columns), ["source", "target", "raw_separation"])

    def test_separation_z_score_keeps_the_z_column(self):
        tables = engine.proximity_table(self.graph, self.matrix,
                                        {"a": {0}}, {"b": {7}},
                                        null_model="uniform", n_iter=50,
                                        score="separation_z_score")
        tidy = engine.long_form(tables, "separation_z_score")
        self.assertEqual(list(tidy.columns)[:3], ["source", "target", "z_score"])
        self.assertIn("raw_separation", tidy.columns)

    def test_lcc_table_reports_one_row_per_set(self):
        table = engine.lcc_table(self.graph, {"a": {0, 1}, "b": {4, 5, 6}},
                                 null_model="uniform", n_iter=50)
        self.assertEqual(len(table), 2)
        self.assertIn("lcc_size", table.columns)


if __name__ == "__main__":
    unittest.main()
