"""End-to-end web test: upload, run the job, read the table, fetch the CSV."""
from __future__ import annotations

import io
import time
import unittest

from netmedscope import web


def _network_csv() -> bytes:
    """A 21-node path; every gene of interest sits on the same component."""
    lines = ["EntrezA,EntrezB"]
    for i in range(20):
        lines.append(f"{i},{i + 1}")
    return ("\n".join(lines) + "\n").encode()


def _drugs_csv() -> bytes:
    return b"chemical,entrez_id\ncompound-a,0\ncompound-a,1\ncompound-b,2\n"


def _diseases_csv() -> bytes:
    return b"disease,entrez_id\ndisease-x,18\ndisease-y,10\n"


class WebFlowTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = web.app.test_client()

    def _submit(self, network: bytes, drugs: bytes, diseases: bytes,
                iterations: str = "50") -> str:
        response = self.client.post(
            "/api/run",
            data={
                "network": (io.BytesIO(network), "net.csv"),
                "drugs": (io.BytesIO(drugs), "drugs.csv"),
                "diseases": (io.BytesIO(diseases), "diseases.csv"),
                "metric": "shortest_path", "null_model": "uniform",
                "iterations": iterations, "max_nodes": "50", "processors": "1",
                "source_col": "EntrezA", "target_col": "EntrezB",
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 200, response.data[:300])
        return response.get_json()["job_id"]

    def _wait(self, job_id: str, timeout: float = 300) -> dict:
        state: dict = {}
        deadline = time.time() + timeout
        while time.time() < deadline:
            state = self.client.get(f"/api/job/{job_id}").get_json()
            if state["state"] in ("done", "error"):
                return state
            time.sleep(1)
        return state

    def test_a_disconnected_set_is_reported_not_crashed(self):
        """A set outside the main component must show coverage 0, not fail the run."""
        stranded = ("EntrezA,EntrezB\n0,1\n1,2\n3,4\n").encode()
        response = self.client.post(
            "/api/run",
            data={
                "network": (io.BytesIO(stranded), "net.csv"),
                "drugs": (io.BytesIO(_drugs_csv()), "drugs.csv"),
                "diseases": (io.BytesIO(b"disease,entrez_id\nlost,3\n"), "d.csv"),
                "metric": "shortest_path", "null_model": "uniform",
                "iterations": "20", "max_nodes": "50", "processors": "1",
                "source_col": "EntrezA", "target_col": "EntrezB",
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 200)
        job_id = response.get_json()["job_id"]
        state = self._wait(job_id)
        self.assertIn(state["state"], ("done", "error"))
        if state["state"] == "error":
            # Losing every target set is a legitimate error, not a crash.
            self.assertIn("交集", state["message"])

    def test_run_completes_and_returns_a_table(self):
        response = self.client.post(
            "/api/run",
            data={
                "network": (io.BytesIO(_network_csv()), "net.csv"),
                "drugs": (io.BytesIO(_drugs_csv()), "drugs.csv"),
                "diseases": (io.BytesIO(_diseases_csv()), "diseases.csv"),
                "metric": "shortest_path",
                "null_model": "uniform",
                "iterations": "50",
                "max_nodes": "50",
                "processors": "1",
                "source_col": "EntrezA",
                "target_col": "EntrezB",
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 200, response.data[:300])
        job_id = response.get_json()["job_id"]

        state = self._wait(job_id)

        self.assertEqual(state["state"], "done", state.get("traceback") or state.get("message"))
        self.assertIn("z_score", state["columns"])
        self.assertGreater(len(state["rows"]), 0)
        # Every gene set must still be represented; dropping a set was the bug.
        for name, count in state["coverage"]["drugs"].items():
            self.assertGreater(count, 0, f"drug set {name} lost")
        for name, count in state["coverage"]["diseases"].items():
            self.assertGreater(count, 0, f"disease set {name} lost")
        for row in state["rows"]:
            self.assertIsInstance(row["z_score"], (int, float))
        # LCC section is part of the page contract now.
        self.assertIn("lcc_size", state["lcc_columns"])
        self.assertGreater(len(state["lcc_rows"]), 0)
        self.assertEqual(set(state["charts"]), {"proximity", "heatmap", "lcc"})

    def test_download_returns_csv(self):
        job_id = self._submit(_network_csv(), _drugs_csv(), _diseases_csv())
        state = self._wait(job_id)
        self.assertEqual(state["state"], "done", state.get("message"))
        response = self.client.get(f"/api/job/{job_id}/proximity.csv")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"z_score", response.data)

    def test_lcc_csv_and_charts_are_exported(self):
        job_id = self._submit(_network_csv(), _drugs_csv(), _diseases_csv())
        state = self._wait(job_id)
        self.assertEqual(state["state"], "done", state.get("message"))

        lcc = self.client.get(f"/api/job/{job_id}/lcc.csv")
        self.assertEqual(lcc.status_code, 200)
        self.assertIn(b"lcc_size", lcc.data)

        for name in ("proximity", "heatmap", "lcc"):
            chart = self.client.get(f"/api/job/{job_id}/chart/{name}.svg")
            self.assertEqual(chart.status_code, 200, name)
            body = chart.get_data(as_text=True)
            self.assertTrue(body.startswith("<svg"), name)
            self.assertIn("</svg>", body)

    def test_report_and_plain_language_summary(self):
        """A non-programmer must get one readable sentence and one shareable file."""
        job_id = self._submit(_network_csv(), _drugs_csv(), _diseases_csv())
        state = self._wait(job_id)
        self.assertEqual(state["state"], "done", state.get("message"))

        summary = state.get("summary", "")
        self.assertTrue(summary.endswith("。"), summary)
        # The wording follows the sign of z: "closest" only when it really is closer.
        self.assertTrue("与疾病最接近的是" in summary
                        or "排名最靠前的是" in summary, summary)
        self.assertIn("最像模块的基因集", summary)

        report = self.client.get(f"/api/job/{job_id}/report.html")
        self.assertEqual(report.status_code, 200)
        body = report.get_data(as_text=True)
        self.assertIn("网络医学分析报告", body)
        self.assertIn("一句话结论", body)
        self.assertGreaterEqual(body.count("<svg"), 3)   # charts are inlined
        self.assertIn("最大连通分量", body)              # Chinese headers
        self.assertIn("NetMedPy", body)

    def test_bundled_example_runs(self):
        """The page must be usable with no files at all."""
        response = self.client.post("/api/run-example", data={"iterations": "30"})
        self.assertEqual(response.status_code, 200, response.data[:300])
        job_id = response.get_json()["job_id"]
        state = self._wait(job_id, timeout=600)
        self.assertEqual(state["state"], "done",
                         state.get("traceback") or state.get("message"))
        self.assertGreater(len(state["rows"]), 0)
        self.assertGreater(len(state["lcc_rows"]), 0)
        for name in ("proximity", "heatmap", "lcc"):
            self.assertEqual(
                self.client.get(f"/api/job/{job_id}/chart/{name}.svg").status_code,
                200, name)

    def test_unknown_chart_is_rejected(self):
        job_id = self._submit(_network_csv(), _drugs_csv(), _diseases_csv())
        self._wait(job_id)
        self.assertEqual(
            self.client.get(f"/api/job/{job_id}/chart/evil.svg").status_code, 404)


if __name__ == "__main__":
    unittest.main()
