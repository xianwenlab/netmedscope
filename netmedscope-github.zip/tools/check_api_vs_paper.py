"""Which paper-mentioned options does the installed NetMedPy actually expose?

The paper promises (i) symmetric and asymmetric proximity, (ii) user-defined
distance metrics, (iii) user-provided null models, (iv) LCC extraction.  This
prints the signatures so the platform comparison is based on the real API.
"""
from __future__ import annotations

import inspect

import netmedpy

for name in ("proximity", "screening", "all_pair_distances", "extract_lcc",
             "lcc_significance"):
    fn = getattr(netmedpy, name, None)
    if fn is None:
        print(f"{name}: MISSING")
        continue
    print(f"{name}{inspect.signature(fn)}")

print("\nscreening doc (first 400 chars):")
print((netmedpy.screening.__doc__ or "")[:400])
