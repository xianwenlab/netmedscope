"""Stage a clean, renamed repository for GitHub: NetMedScope.

Copies the working platform into ``交付/netmedscope-github`` as package
``netmedscope`` (renamed from ``netmedscope``), rewrites imports, and writes
the files a public repo needs: README, pyproject, .gitignore, start.bat.
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path

SRC = Path(r"D:\Drugdiscovery\NetMedPy-Platform")
DST = Path(r"D:\Drugdiscovery\交付\netmedscope-github")

SKIP_DIRS = {".venv", "__pycache__", "results", "tmp_cache", ".git", ".pytest_cache"}
SKIP_SUFFIX = {".pyc", ".log", ".svg", ".png", ".zip"}
TEXT_SUFFIX = {".py", ".md", ".txt", ".bat", ".html", ".toml", ".cff", ".gitignore"}

README = """# NetMedScope

An offline web workbench for network-medicine screening.

NetMedScope does **not** invent a new method: the science — proximity/separation
z-scores, null models, LCC significance — is [NetMedPy](https://pypi.org/project/netmedpy/)
(Aldana et al., *Bioinformatics* 2025). What this project adds is the part that
stops a bench biologist: parsing inputs, cutting an analysable sub-network,
caching distance matrices, running the permutations, explaining the numbers in
plain language, drawing the figures and exporting one shareable report.

> Windows 10/11 · local computation · no coding required

## Why it exists

The paper's Python API expects you to write code, know what a null model is, and
know that a *negative* z means "closer than chance". NetMedScope turns that into:
three file inputs, one button, one sentence of Chinese, one HTML report you can
mail to your supervisor.

## Quick start

```bat
start.bat
```

Then open <http://127.0.0.1:8300>, click **载入示例并运行** (load the bundled
example) — no data needed. First run creates `.venv` and installs dependencies
(3–5 min); later starts take seconds.

Command line, if you prefer:

```bash
pip install -r requirements.txt
python -m netmedscope.cli --network examples/network.csv \\
  --drugs examples/drugs.csv --diseases examples/diseases.csv \\
  --metric shortest_path --null uniform --iterations 1000 --out results/run1
```

## What you get

| Output | Where |
|---|---|
| Pair-level scores (proximity / separation / separation-z) | `proximity.csv` (or `<score>.csv`) |
| Matrix view of the same numbers | `<score>_wide.csv` |
| LCC size, z and p per gene set | `lcc.csv` |
| Figures (bar chart, heatmap, LCC chart) | `*.svg` |
| Provenance: options, input hashes, timings, versions | `run.json` |
| One shareable report with charts inlined | `/api/job/<id>/report.html` |

## Parameters, in one screen

- **distance**: shortest path (AMSPL, usual), random walk (robust to incomplete
  networks), biased random walk (degree weighted), communicability (all paths).
- **null model**: degree match (strictest), log binning, strength binning,
  uniform (fastest).
- **z sign**: proximity/separation z = (observed − random)/sd, so **negative means
  closer than chance**; LCC z is the opposite — **positive means more clustered**.
  Verified in `tests/`.
- **iterations**: permutation count; the smallest resolvable p is 1/(N+1), so use
  1000+ for a real analysis.
- **raw separation has no null model** in NetMedPy, so it has no z/p at all — the
  UI says so instead of inventing one.

## Repository layout

```
netmedscope/engine.py      input parsing, sub-network, matrix cache, NetMedPy wrappers
netmedscope/charts.py      dependency-free SVG charts (bar, heatmap)
netmedscope/web.py         Flask UI, background jobs, HTML report
netmedscope/cli.py         command line
netmedscope/templates/     page
examples/                  runnable slice of the human interactome + 2 gene sets
tests/                     20 tests (engine, web, report)
tools/                     verification scripts used to check the numbers
```

## Tests

```bash
python -m unittest discover -s tests -v
```

## Attribution and licence

Method and statistics: NetMedPy (MIT). Please cite
Aldana A. et al. *NetMedPy: A Python package for Large-Scale Network Medicine
Screening*. Bioinformatics 2025;41(9):btaf338, and the underlying papers
(Barabási 2011 doi:10.1038/nrg2918; Menche 2015 doi:10.1126/science.1257601;
Guney 2016 doi:10.1038/ncomms10331).

The code in this repository (workflow, caching, charts, report) is MIT licensed;
see `LICENSE`. NetMedScope is not affiliated with the NetMedPy authors.

## Known limits

- Only `shortest_path` has been exercised on real data so far; the other metrics
  are wired but slower (communicability especially).
- Permutation p-values are coarse below 1000 iterations.
- The web UI has automated tests but has not been through a manual browser pass.
- Custom distance functions and custom null models are CLI-only territory: the
  web form deliberately does not accept code.
"""

PYPROJECT = """[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "netmedscope"
version = "0.1.0"
description = "Offline web workbench for NetMedPy network-medicine screening"
readme = "README.md"
requires-python = ">=3.10"
license = {text = "MIT"}
dependencies = [
    "netmedpy>=0.2.0.1",
    "networkx>=3.0",
    "numpy>=1.24",
    "pandas>=2.0",
    "flask>=3.0",
]

[project.scripts]
netmedscope = "netmedscope.cli:main"

[tool.setuptools]
packages = ["netmedscope"]

[tool.setuptools.package-data]
netmedscope = ["templates/*.html"]
"""

MIT = """MIT License

Copyright (c) 2026 Xianwen Ye

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

GITIGNORE = """__pycache__/
*.pyc
.venv/
venv/
results/
tmp_cache/
*.log
*.zip
.DS_Store
Thumbs.db
.vscode/
.idea/
"""

START_BAT = """@echo off
setlocal
cd /d "%~dp0"
title NetMedScope

if exist ".venv\\Scripts\\python.exe" goto run

echo [1/3] Creating the virtual environment...
where py >nul 2>nul
if not errorlevel 1 (py -3 -m venv .venv) else (python -m venv .venv)
if not exist ".venv\\Scripts\\python.exe" (
    echo ERROR: Python 3.10+ not found. Install it and tick "Add python.exe to PATH".
    pause
    exit /b 1
)
echo [2/3] Installing dependencies ^(first run only^)...
".venv\\Scripts\\python.exe" -m pip install --upgrade pip
".venv\\Scripts\\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    ".venv\\Scripts\\python.exe" -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
)
if errorlevel 1 (echo ERROR: install failed. & pause & exit /b 1)

:run
echo [3/3] Opening http://127.0.0.1:8300 ...
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 4; Start-Process 'http://127.0.0.1:8300'"
".venv\\Scripts\\python.exe" -m netmedscope.web 8300
echo.
echo The server has stopped.
pause
"""


def copy_tree() -> None:
    if DST.exists():
        shutil.rmtree(DST)
    DST.mkdir(parents=True)
    (DST / "netmedscope").mkdir()
    for name in ("templates",):
        shutil.copytree(SRC / "netmedscope" / name, DST / "netmedscope" / name)
    for path in (SRC / "netmedscope").glob("*.py"):
        shutil.copy2(path, DST / "netmedscope" / path.name)
    for name in ("tests", "examples", "tools"):
        shutil.copytree(SRC / name, DST / name,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.log"))


def rewrite() -> None:
    for path in DST.rglob("*"):
        if not path.is_file():
            continue
        if path.name == "start.bat" or path.suffix.lower() not in TEXT_SUFFIX:
            if path.name != "start.bat":
                continue
        if path.suffix.lower() in SKIP_SUFFIX:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        new = text.replace("netmedscope", "netmedscope")
        if new != text:
            path.write_text(new, encoding="utf-8")
            print("rewrote", path.relative_to(DST))


def write_support_files() -> None:
    (DST / "README.md").write_text(README, encoding="utf-8")
    (DST / "pyproject.toml").write_text(PYPROJECT, encoding="utf-8")
    (DST / ".gitignore").write_text(GITIGNORE, encoding="utf-8")
    (DST / "start.bat").write_bytes(START_BAT.replace("\n", "\r\n").encode("ascii"))
    shutil.copy2(SRC / "requirements.txt", DST / "requirements.txt")
    (DST / "LICENSE").write_text(MIT, encoding="utf-8")
    (DST / "docs").mkdir(exist_ok=True)
    print("wrote README.md, pyproject.toml, .gitignore, start.bat")


def main() -> None:
    copy_tree()
    write_support_files()
    rewrite()
    files = [p for p in DST.rglob("*") if p.is_file()]
    print(f"staged {len(files)} files in {DST}")
    for path in sorted(files)[:12]:
        print("  ", path.relative_to(DST))


if __name__ == "__main__":
    main()
