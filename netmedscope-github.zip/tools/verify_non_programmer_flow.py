"""Verify the non-coder workflow end to end: page, summary, shareable report."""
from __future__ import annotations

import io
import time
from pathlib import Path

from netmedscope import web

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results" / "report-demo"


def main() -> None:
    client = web.app.test_client()

    page = client.get("/").get_data(as_text=True)
    print("=== page ===")
    for name, ok in {
        "高级选项折叠": "高级选项（一般不用改）" in page,
        "分析类型可读标签": "分析类型（默认即可）" in page,
        "对称邻近度开关": 'name="symmetric"' in page,
        "中文表头映射": "最大连通分量" in page and "const ZH" in page,
        "一句话结论卡片": "一句话结论" in page,
        "报告下载入口": "report.html" in page,
        "友好报错提示": "常见原因" in page,
    }.items():
        print(("PASS  " if ok else "FAIL  ") + name)
    print("page bytes:", len(page))

    print("\n=== example run ===")
    response = client.post("/api/run-example", data={"iterations": "100"})
    print("submit:", response.status_code)
    job_id = response.get_json()["job_id"]

    state = {}
    deadline = time.time() + 900
    while time.time() < deadline:
        state = client.get(f"/api/job/{job_id}").get_json()
        if state["state"] in ("done", "error"):
            break
        time.sleep(2)

    print("state:", state["state"], "|", state.get("message"))
    if state["state"] != "done":
        print((state.get("traceback") or "")[-600:])
        raise SystemExit(1)

    print("summary:", state.get("summary"))
    print("columns:", state["columns"], "| rows:", len(state["rows"]),
          "| lcc rows:", len(state["lcc_rows"]))

    report = client.get(f"/api/job/{job_id}/report.html")
    body = report.get_data(as_text=True)
    print("\n=== report ===")
    print("status:", report.status_code, "| bytes:", len(body),
          "| inline <svg>:", body.count("<svg"))
    print("has 结论:", "一句话结论" in body)
    print("has 参数表:", "运行参数" in body)
    print("has 中文表头:", "最大连通分量" in body and "平均最近距离" in body)
    print("has 图表:", body.count("<h3>") >= 3)

    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"report-{job_id}.html"
    target.write_text(body, encoding="utf-8")
    (OUT / "summary.txt").write_text(state.get("summary", ""), encoding="utf-8")
    print("saved:", target, target.stat().st_size, "bytes")


if __name__ == "__main__":
    main()
