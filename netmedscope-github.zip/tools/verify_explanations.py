"""Check the page explains the parameters, and that the separation score runs end to end.

NetMedPy uses a spawn pool for distance matrices, so the run has to sit behind the
__main__ guard.
"""
from __future__ import annotations

import io
import time
from pathlib import Path

from netmedscope import web

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


def check_page(client) -> None:
    page = client.get("/").get_data(as_text=True)
    checks = {
        "参数与结果含义": "参数与结果含义" in page,
        "分析类型 dropdown entries": page.count('name="score"') >= 1
                                     and "proximity" in page and "separation_z_score" in page,
        "邻近度 explanation": "邻近度 proximity（raw_amspl）" in page,
        "分离度 explanation": "分离度 separation（raw_separation）" in page,
        "z sign (proximity)": "负值 = 比随机更靠近" in page,
        "z sign (LCC)": "LCC 表的 z_score" in page and "正值 = 比随机更聚集" in page,
        "p resolution note": "1/(N+1)" in page,
        "distance metrics explained": "传播性 communicability" in page,
        "null models explained": "度完美匹配" in page and "均匀抽样" in page,
        "result fields explained": "genes_in_network" in page and "lcc_size" in page,
    }
    print("=== page ===")
    for name, ok in checks.items():
        print(("PASS  " if ok else "FAIL  ") + name)
    print("page bytes:", len(page))


def check_separation(client) -> None:
    print("\n=== web run with score=separation ===")
    response = client.post(
        "/api/run", content_type="multipart/form-data",
        data={
            "network": (io.BytesIO((EXAMPLES / "network.csv").read_bytes()), "net.csv"),
            "drugs": (io.BytesIO((EXAMPLES / "drugs.csv").read_bytes()), "drugs.csv"),
            "diseases": (io.BytesIO((EXAMPLES / "diseases.csv").read_bytes()), "dis.csv"),
            "score": "separation", "metric": "shortest_path", "null_model": "uniform",
            "iterations": "50", "max_nodes": "800", "processors": "1",
            "source_col": "EntrezA", "target_col": "EntrezB",
        })
    print("submit:", response.status_code)
    job_id = response.get_json()["job_id"]
    state = {}
    deadline = time.time() + 600
    while time.time() < deadline:
        state = client.get(f"/api/job/{job_id}").get_json()
        if state["state"] in ("done", "error"):
            break
        time.sleep(1)
    print("state:", state["state"], "|", state.get("message"))
    if state["state"] != "done":
        print((state.get("traceback") or "")[-600:])
        return
    print("score:", state["score"], "| ranking:", state["ranking"])
    print("columns:", state["columns"])
    print("rows:", len(state["rows"]), "| lcc rows:", len(state["lcc_rows"]))
    print("first row:", state["rows"][0])
    for name in ("proximity", "heatmap", "lcc"):
        body = client.get(f"/api/job/{job_id}/chart/{name}.svg").get_data(as_text=True)
        title = body.split("<title>")[0][:0]
        print(f"  {name}.svg: {len(body)} bytes, has svg={body.startswith('<svg')}")
    header = client.get(f"/api/job/{job_id}/proximity.csv").get_data()
    print("  proximity.csv header:", io.BytesIO(header).readline().decode().strip())


def main() -> None:
    client = web.app.test_client()
    check_page(client)
    check_separation(client)


if __name__ == "__main__":
    main()
