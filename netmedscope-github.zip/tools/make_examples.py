"""Build the bundled example inputs from the project's interactome.

The platform should be runnable the moment it is unpacked, so the examples are a
small connected slice of the real network plus two real gene sets.  They are a
smoke test of the pipeline, not a biological result: the README says so.
"""
from __future__ import annotations

from pathlib import Path

import networkx as nx
import pandas as pd

from netmedscope import engine

PROJECT = Path(r"D:\Drugdiscovery\NetworkMedicine-Calculator\data")
TARGET = Path(r"D:\Drugdiscovery\NetMedPy-Platform\examples")


def main() -> None:
    TARGET.mkdir(parents=True, exist_ok=True)

    graph = engine.read_edge_list(PROJECT / "HumanInteractome_v2017.csv",
                                  "EntrezA", "EntrezB")
    print(f"full network: {graph.number_of_nodes()} nodes, "
          f"{graph.number_of_edges()} edges")

    drugs = engine.read_gene_sets(PROJECT / "demo" / "demo_drug_targets.csv",
                                  "chemical", "entrez_id")
    diseases = engine.read_gene_sets(PROJECT / "demo" / "demo_disease_genes.csv",
                                     "disease", "entrez_id")

    # A 250-node slice keeps the example fast (<2 s matrix) while staying real.
    sub = engine.focus_subgraph(graph, {**drugs, **diseases}, max_nodes=250)
    print(f"example slice: {sub.number_of_nodes()} nodes, "
          f"{sub.number_of_edges()} edges")

    nodes = set(sub.nodes)
    kept_drugs = {name: genes & nodes for name, genes in drugs.items()}
    kept_diseases = {name: genes & nodes for name, genes in diseases.items()}
    kept_drugs = {k: v for k, v in kept_drugs.items() if v}
    kept_diseases = {k: v for k, v in kept_diseases.items() if v}

    for name, genes in kept_drugs.items():
        print(f"  drug {name}: {len(genes)} genes")
    for name, genes in kept_diseases.items():
        print(f"  disease {name}: {len(genes)} genes")

    edges = pd.DataFrame(sorted((min(a, b), max(a, b)) for a, b in sub.edges()),
                         columns=["EntrezA", "EntrezB"])
    edges.to_csv(TARGET / "network.csv", index=False, encoding="utf-8")
    print("wrote network.csv:", edges.shape)

    rows = [(name, gene) for name, genes in kept_drugs.items() for gene in sorted(genes)]
    pd.DataFrame(rows, columns=["chemical", "entrez_id"]).to_csv(
        TARGET / "drugs.csv", index=False, encoding="utf-8")
    print("wrote drugs.csv:", len(rows), "rows")

    rows = [(name, gene) for name, genes in kept_diseases.items()
            for gene in sorted(genes)]
    pd.DataFrame(rows, columns=["disease", "entrez_id"]).to_csv(
        TARGET / "diseases.csv", index=False, encoding="utf-8")
    print("wrote diseases.csv:", len(rows), "rows")

    # Everything in the sets must exist in the network, or the example misleads.
    missing = (set(g for genes in kept_drugs.values() for g in genes)
               | set(g for genes in kept_diseases.values() for g in genes)) - nodes
    print("genes outside the slice:", len(missing))
    assert not missing, missing
    assert nx.is_connected(sub), "example network must be connected"


if __name__ == "__main__":
    main()
