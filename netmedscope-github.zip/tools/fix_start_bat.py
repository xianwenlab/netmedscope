"""Rewrite start.bat as ASCII with CRLF, and make it self-installing.

cmd.exe needs CRLF line endings and reads the file in the OEM code page: an
LF-only batch with UTF-8 Chinese gets split into fragments and executed line by
line ("'级' is not recognized as an internal or external command"), which is
exactly what the double-click produced.
"""
from pathlib import Path

BATCH = r"""@echo off
setlocal
cd /d "%~dp0"
title Network Medicine Platform

if exist ".venv\Scripts\python.exe" goto run

echo [1/3] Creating the virtual environment...
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -m venv .venv
) else (
    python -m venv .venv
)
if not exist ".venv\Scripts\python.exe" (
    echo.
    echo ERROR: Python 3.10+ was not found.
    echo Install it from https://www.python.org/downloads/ and tick
    echo "Add python.exe to PATH", then run this file again.
    echo.
    pause
    exit /b 1
)

echo [2/3] Installing dependencies ^(first run only^)...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo Default index failed, retrying with a mirror...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
)
if errorlevel 1 (
    echo.
    echo ERROR: dependency installation failed. Check the network and retry.
    pause
    exit /b 1
)

:run
echo [3/3] Opening http://127.0.0.1:8300 ...
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 4; Start-Process 'http://127.0.0.1:8300'"
".venv\Scripts\python.exe" -m netmedscope.web 8300
echo.
echo The server has stopped.
pause
"""

path = Path(r"D:\Drugdiscovery\NetMedPy-Platform\start.bat")
path.write_bytes(BATCH.replace("\n", "\r\n").encode("ascii"))
print("wrote", path, path.stat().st_size, "bytes")
