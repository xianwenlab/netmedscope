"""Real-data check of the LCC page and chart export.

NetMedPy computes distance matrices in a spawn process pool, so everything must
sit behind the __main__ guard -- otherwise the workers re-import this file and the
job hangs at the matrix step.
"""
from __future__ import annotations

import io
import re
import time
from pathlib import Path

import pandas as pd

from netmedscope import web

DATA = Path(r"D:\Drugdiscovery\NetworkMedicine-Calculator\data")


def main() -> int:
    client = web.app.test_client()
    response = client.post(
        "/api/run",
        data={
            "network": (io.BytesIO((DATA / "HumanInteractome_v2017.csv").read_bytes()),
                        "net.csv"),
            "drugs": (io.BytesIO((DATA / "demo" / "demo_drug_targets.csv").read_bytes()),
                      "drugs.csv"),
            "diseases": (io.BytesIO((DATA / "demo" / "demo_disease_genes.csv").read_bytes()),
                         "diseases.csv"),
            "metric": "shortest_path", "null_model": "uniform",
            "iterations": "50", "max_nodes": "400", "processors": "1",
            "source_col": "EntrezA", "target_col": "EntrezB",
        },
        content_type="multipart/form-data",
    )
    assert response.status_code == 200, response.data[:300]
    job_id = response.get_json()["job_id"]

    state = {}
    deadline = time.time() + 600
    while time.time() < deadline:
        state = client.get(f"/api/job/{job_id}").get_json()
        if state["state"] in ("done", "error"):
            break
        time.sleep(2)

    print("job:", state.get("state"), "|", state.get("message"))
    if state.get("state") != "done":
        print((state.get("traceback") or "")[-700:])
        return 1

    print("graph:", state["graph"], "| matrix:", state["matrix"])
    print("coverage:", state["coverage"])
    print("lcc columns:", state["lcc_columns"])
    print("lcc rows:", len(state["lcc_rows"]))
    print("first lcc row:", state["lcc_rows"][0])

    lcc = client.get(f"/api/job/{job_id}/lcc.csv")
    frame = pd.read_csv(io.BytesIO(lcc.data))
    print("lcc.csv:", frame.shape, "| sets:", list(frame["set"]))
    print("lcc z range: %.2f .. %.2f" % (frame.z_score.min(), frame.z_score.max()))

    for name in ("proximity", "heatmap", "lcc"):
        chart = client.get(f"/api/job/{job_id}/chart/{name}.svg")
        body = chart.get_data(as_text=True)
        rects = len(re.findall(r"<rect ", body))
        texts = re.findall(r">([^<>]{2,20})</text>", body)
        print(f"{name}.svg: status={chart.status_code} bytes={len(body)} "
              f"rects={rects} texts={len(texts)} sample={texts[1:3]}")

    page = client.get("/").get_data(as_text=True)
    print("page has LCC section:", "LCC 网络定位" in page)
    print("page renders charts:", "charts.heatmap" in page)
    print("workdir:", state["workdir"])
    for item in sorted(Path(state["workdir"]).iterdir()):
        print(f"  {item.name:<22}{item.stat().st_size:>8} B")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
