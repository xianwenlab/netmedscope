"""Confirm the page really serves the references section."""
from __future__ import annotations

from netmedscope import web

client = web.app.test_client()
page = client.get("/").get_data(as_text=True)

checks = {
    "方法说明 section": "方法说明" in page,
    "参考文献 heading": "参考文献" in page,
    "Barabási 2011": "10.1038/nrg2918" in page,
    "Menche 2015 (text only)": "10.1126/science.1257601" in page,
    "Guney 2016": "10.1038/ncomms10331" in page,
    "NetMedPy package": "pypi.org/project/netmedpy" in page,
}
for name, ok in checks.items():
    print(("PASS  " if ok else "FAIL  ") + name)
print("page bytes:", len(page))
