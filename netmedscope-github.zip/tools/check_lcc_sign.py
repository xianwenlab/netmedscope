"""What does the sign of LCC z mean? Clustered vs scattered gene sets."""
from __future__ import annotations

import networkx as nx

import netmedpy


def main() -> None:
    graph = nx.path_graph(12)          # 0..11 in a line
    graph.add_edges_from([(0, 1), (1, 2), (2, 0)])   # make 0,1,2 a tight triangle
    clustered = {0, 1, 2}
    scattered = {0, 5, 11}
    for name, genes in (("clustered", clustered), ("scattered", scattered)):
        data = netmedpy.lcc_significance(graph, genes, null_model="uniform",
                                         n_iter=300)
        print(name, {k: round(float(v), 3) if isinstance(v, (int, float)) else v
                     for k, v in data.items()})


if __name__ == "__main__":
    main()
