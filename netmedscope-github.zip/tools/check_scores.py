"""Which scores does screening accept, and what does the sign of z mean?

Run as a script: NetMedPy uses a spawn pool for distance matrices.
"""
from __future__ import annotations

import inspect

import networkx as nx
import pandas as pd

import netmedpy
from netmedscope import engine


def main() -> None:
    source = inspect.getsource(netmedpy.screening)
    for line in source.splitlines():
        if "score" in line and ("==" in line or "in (" in line or "elif" in line):
            print("score branch:", line.strip()[:120])

    print("\n--- sign convention on a path graph 0..9 ---")
    graph = nx.path_graph(10)
    matrix, _ = engine.distance_matrix(graph, "shortest_path", "tmp_cache",
                                       n_processors=1)
    tables = netmedpy.screening(
        {"src": {0}}, {"near": {1}, "far": {9}}, graph, matrix,
        score="proximity", properties=["z_score", "raw_amspl", "p_value_single_tail"],
        null_model="uniform", n_iter=300)
    for key, table in tables.items():
        print(key, pd.DataFrame(table).to_dict())

    print("\n--- separation ---")
    try:
        sep = netmedpy.screening(
            {"src": {0}}, {"near": {1}, "far": {9}}, graph, matrix,
            score="separation", properties=["z_score", "raw_amspl"],
            null_model="uniform", n_iter=100)
        for key, table in sep.items():
            print("sep", key, pd.DataFrame(table).to_dict())
    except Exception as exc:                        # noqa: BLE001
        print("separation failed:", type(exc).__name__, exc)


if __name__ == "__main__":
    main()
