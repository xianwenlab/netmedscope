"""Verify the bundled examples through both entry points.

Runs the CLI on examples/ and the web "load example" endpoint, then prints what
each actually produced so the numbers can be checked, not assumed.
"""
from __future__ import annotations

import io
import time
from pathlib import Path

import pandas as pd

from netmedscope import cli, web

ROOT = Path(__file__).resolve().parent.parent
EXAMPLES = ROOT / "examples"
OUT = ROOT / "results" / "example"


def check_cli() -> None:
    print("=== CLI on examples/ ===")
    code = cli.main([
        "--network", str(EXAMPLES / "network.csv"),
        "--drugs", str(EXAMPLES / "drugs.csv"),
        "--diseases", str(EXAMPLES / "diseases.csv"),
        "--metric", "shortest_path", "--null", "uniform",
        "--iterations", "100", "--max-nodes", "800", "--out", str(OUT),
    ])
    print("cli exit:", code)

    proximity = pd.read_csv(OUT / "proximity.csv")
    lcc = pd.read_csv(OUT / "lcc.csv")
    print("proximity.csv:", proximity.shape, list(proximity.columns))
    print("  pairs:", len(proximity), "| z range %.2f..%.2f"
          % (proximity.z_score.min(), proximity.z_score.max()))
    print("lcc.csv:", lcc.shape, list(lcc.columns))
    print("  sets:", list(lcc["set"]), "| lcc sizes:", list(lcc["lcc_size"]))
    print("files:", sorted(p.name for p in OUT.iterdir() if p.is_file()))


def check_web() -> None:
    print("\n=== web /api/run-example ===")
    client = web.app.test_client()
    response = client.post("/api/run-example", data={"iterations": "100"})
    print("submit:", response.status_code)
    job_id = response.get_json()["job_id"]

    state = {}
    deadline = time.time() + 600
    while time.time() < deadline:
        state = client.get(f"/api/job/{job_id}").get_json()
        if state["state"] in ("done", "error"):
            break
        time.sleep(1)

    print("state:", state["state"], "|", state.get("message"))
    if state["state"] != "done":
        print((state.get("traceback") or "")[-600:])
        return
    print("graph:", state["graph"], "| matrix:", state["matrix"])
    print("coverage:", state["coverage"])
    print("proximity rows:", len(state["rows"]),
          "| lcc rows:", len(state["lcc_rows"]))
    print("first proximity row:", state["rows"][0])
    print("first lcc row:", state["lcc_rows"][0])
    for name in ("proximity", "heatmap", "lcc"):
        body = client.get(f"/api/job/{job_id}/chart/{name}.svg").get_data()
        print(f"  {name}.svg: {len(body)} bytes")
    lcc_csv = client.get(f"/api/job/{job_id}/lcc.csv").get_data()
    print("  lcc.csv header:", io.BytesIO(lcc_csv).readline().decode().strip())


if __name__ == "__main__":
    check_cli()
    check_web()
