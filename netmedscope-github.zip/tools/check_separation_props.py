"""Which property names does each score accept?"""
from __future__ import annotations

import networkx as nx
import pandas as pd

import netmedpy
from netmedscope import engine


def main() -> None:
    graph = nx.path_graph(10)
    matrix, _ = engine.distance_matrix(graph, "shortest_path", "tmp_cache",
                                       n_processors=1)
    candidates = ["z_score", "raw_separation", "raw_separation_z", "raw_amspl",
                  "p_value_single_tail", "p_value_double_tail"]
    for score in ("separation", "separation_z_score"):
        accepted = []
        for prop in candidates:
            try:
                netmedpy.screening({"a": {0}}, {"b": {9}}, graph, matrix,
                                   score=score, properties=[prop],
                                   null_model="uniform", n_iter=50)
                accepted.append(prop)
            except Exception as exc:                # noqa: BLE001
                pass
        print(score, "accepts:", accepted)

    tables = netmedpy.screening({"a": {0}, "c": {1}}, {"b": {9}}, graph, matrix,
                                score="separation",
                                properties=["z_score", "raw_separation"],
                                null_model="uniform", n_iter=100)
    for key, table in tables.items():
        print("separation", key, pd.DataFrame(table).to_dict())


if __name__ == "__main__":
    main()
