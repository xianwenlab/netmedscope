"""Verify the platform's deliverables actually contain what they claim."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from netmedscope import web

root = Path(r"D:\Drugdiscovery\NetMedPy-Platform")
out = root / "results" / "demo"

proximity = pd.read_csv(out / "proximity.csv")
print("proximity.csv:", proximity.shape, list(proximity.columns))
print("  z range: %.2f .. %.2f" % (proximity.z_score.min(), proximity.z_score.max()))
print("  pairs:", sorted(proximity.source.unique()), "x",
      sorted(proximity.target.unique()))

wide = pd.read_csv(out / "proximity_wide.csv", index_col=0)
print("proximity_wide.csv:", wide.shape, "| index:", list(wide.index))

lcc = pd.read_csv(out / "lcc.csv")
print("lcc.csv:", lcc.shape, list(lcc.columns))

meta = json.loads((out / "run.json").read_text(encoding="utf-8"))
print("run.json keys:", sorted(meta))
print("  graph:", meta["graph"], "| matrix:", meta["matrix"]["metric"],
      meta["matrix"]["seconds"], "s cached=", meta["matrix"]["cached"])
print("  pairs:", meta["pairs"], "| total seconds:", meta["seconds"],
      "| engine:", meta["engine"])
print("  coverage:", meta["coverage"])

client = web.app.test_client()
page = client.get("/")
print("index page:", page.status_code,
      "| contains title:", "网络医学分析平台" in page.get_data(as_text=True))
