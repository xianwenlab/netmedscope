@echo off
setlocal
cd /d "%~dp0"
title NetMedScope

if exist ".venv\Scripts\python.exe" goto run

echo [1/3] Creating the virtual environment...
where py >nul 2>nul
if not errorlevel 1 (py -3 -m venv .venv) else (python -m venv .venv)
if not exist ".venv\Scripts\python.exe" (
    echo ERROR: Python 3.10+ not found. Install it and tick "Add python.exe to PATH".
    pause
    exit /b 1
)
echo [2/3] Installing dependencies ^(first run only^)...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
)
if errorlevel 1 (echo ERROR: install failed. & pause & exit /b 1)

:run
echo [3/3] Opening http://127.0.0.1:8300 ...
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 4; Start-Process 'http://127.0.0.1:8300'"
".venv\Scripts\python.exe" -m netmedscope.web 8300
echo.
echo The server has stopped.
pause
